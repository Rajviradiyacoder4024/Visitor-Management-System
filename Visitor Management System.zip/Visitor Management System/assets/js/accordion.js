		$(document).ready(function() {
			$(".topnav").accordionze({
				accordionze:false,
				speed: 500,
				closedSign: '<img src="assets/img/plus.png">',
				openedSign: '<img src="assets/img/minus.png">'
			});
		});

